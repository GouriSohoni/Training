﻿using Windows.UI.Xaml.Controls;

namespace ZUMOAPPNAME
{
    public sealed partial class MainPage : Page
    {
    }
}

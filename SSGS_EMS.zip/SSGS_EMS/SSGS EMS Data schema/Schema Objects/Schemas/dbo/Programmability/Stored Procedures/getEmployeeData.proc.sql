﻿CREATE PROCEDURE [dbo].[getEmployeeData]
AS
	SELECT * FROM EmpMaster
RETURN 0
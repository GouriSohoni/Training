﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Automation_Library_Demo
{
    
    public class Automation
    {
        public int addition(int i, int j)
        {
            int a = i + j;
            return a;
        }
        public int subtract(int i, int j)
        {
            int b = i - j;
            return b;
        }

    }
}

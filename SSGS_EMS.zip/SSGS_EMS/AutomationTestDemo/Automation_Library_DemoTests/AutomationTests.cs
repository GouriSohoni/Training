﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Automation_Library_Demo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Automation_Library_Demo.Tests
{
    [TestClass()]
    public class AutomationTests
    {
        [TestMethod()]
        public void additionTest()
        {
            int i=10, j=10;
            int actual, expected=20;
            Automation_Library_Demo.Automation obj = new Automation_Library_Demo.Automation();

            actual = obj.addition(i, j);
            Assert.AreEqual(expected, actual);
        }
    }
}
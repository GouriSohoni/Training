﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SSGS_EMS_Test_2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://exxat-qa-apps.azurewebsites.net");
            driver.FindElement(By.Id("Username")).SendKeys("Exxat");
            driver.FindElement(By.Id("Password")).SendKeys("P@ssword123");
            driver.FindElement(By.Id("btnLogin")).Click();
            driver.Quit();
        }
    }
}

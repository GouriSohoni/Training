﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
//using Microsoft.QualityTools.Testing.Fakes;
using System.Diagnostics;
//using System.Fakes;
using SSGS_Password_Validator;

namespace SSGS_EMS_Test_Project
{
    //[TestClass]
   // public class UnitTestWithShims
    //{
    //    [TestMethod]
    //    public void TestwithShims()
    //    {
    //        using (ShimsContext.Create())
    //        {
    //            ShimDateTime.NowGet = () => new DateTime(2014, 09, 12);
    //            //DemoShimsClass.DateCheck();
    //            //bool expected = true;
    //            //bool actual = DemoShimsClass.DateCheck();
    //            //Assert.AreEqual(actual, expected, "Dates not matching");
    //        }
            
           
    //    }

    //}
}

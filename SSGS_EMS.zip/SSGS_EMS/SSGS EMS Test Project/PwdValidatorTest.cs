﻿using SSGS_Password_Validator;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
//using NUnit.Framework;

namespace SSGS_EMS_Test_Project
{
    
    
    /// <summary>
    ///This is a test class for PwdValidatorTest and is intended
    ///to contain all PwdValidatorTest Unit Tests
    ///</summary>
    ///
    //[TestFixture]
    //public class NUnitTestClass
    //{
    //    [Test]
    //    public void NUnitTest()
    //    {
    //        PwdValidator target = new PwdValidator();
    //        string password = "password";
    //        bool expected = true;
    //        bool actual;
    //        actual = target.PasswdValidation(password);
    //        NUnit.Framework.Assert.AreEqual(actual, expected);
    //    }
    //}
    [TestClass()]
    public class PwdValidatorTest
    {


        private Microsoft.VisualStudio.TestTools.UnitTesting.TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public Microsoft.VisualStudio.TestTools.UnitTesting.TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for PasswdValidation
        ///</summary>
        //[DataSource("System.Data.SqlClient",
        //    "Data Source=WIN2K8HV\\MSSQL2008;Initial Catalog=\"SSGS EMS Data\";Integrated Security=True;Pooling=False",
        //    "EMSTestData", DataAccessMethod.Sequential), TestMethod()]
        [TestMethod]
        public void PasswdValidationTest()
        {
            PwdValidator target = new PwdValidator(); // TODO: Initialize to an appropriate value
            string password = "P2ssw0rd";// TestContext.DataRow["password"].ToString();
            bool expected = true; //Convert.ToBoolean(TestContext.DataRow["Validity"]);
            bool actual;
            actual = target.PasswdValidation(password);
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void PasswdValidation2Test()
        {
            PwdValidator target = new PwdValidator(); // TODO: Initialize to an appropriate value
            string password = "P2ssw0";// TestContext.DataRow["password"].ToString();
            bool expected = false; //Convert.ToBoolean(TestContext.DataRow["Validity"]);
            bool actual;
            actual = target.PasswdValidation(password);
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(expected, actual);
           
        }
       
        public void UserValidationTest()
        {
            PwdValidator target = new PwdValidator(); // TODO: Initialize to an appropriate value
            string UName = "Gouri";
            bool expected = true;
            bool actual;
            actual = target.UserNameValidation(UName);
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(expected, actual);
        }
        
    }
}

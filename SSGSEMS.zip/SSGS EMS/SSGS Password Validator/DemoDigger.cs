﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SSGS_Password_Validator
{
    class DemoDigger
    {
    }
}

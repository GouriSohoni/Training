﻿CREATE TABLE [dbo].[Departments] (
    [DepId]   INT           NOT NULL,
    [DepName] NVARCHAR (50) NULL
);


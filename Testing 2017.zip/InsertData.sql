INSERT INTO Departments 
VALUES (1,'HR')
INSERT INTO Departments 
VALUES (2,'Sales')
INSERT INTO Departments 
VALUES (3,'IT')

INSERT INTO  EmpMaster (EmpFirstName,EmpLastName,EmpDesignation,EmpDepartment,Pwd)
VALUES ('Gouri','Sohoni','Director','IT','Gouri123')

INSERT INTO  EmpMaster (EmpFirstName,EmpLastName,EmpDesignation,EmpDepartment,Pwd)
VALUES ('Subodh','Sohoni','Director','IT','Subodh')

INSERT INTO  EmpMaster (EmpFirstName,EmpLastName,EmpDesignation,EmpDepartment,Pwd)
VALUES ('Mike','Mehta','Director','HR','Mike123')

INSERT INTO  EmpMaster (EmpFirstName,EmpLastName,EmpDesignation,EmpDepartment,Pwd)
VALUES ('Jerry','F','Director','IT','Jerry123')

INSERT INTO EmpOptionalData (EmpId,EmpEduInfo,EmpFamilyInfo,EmpHobbies)
VALUES (1,'PGDCA','married','reading')

INSERT INTO EmpOptionalData (EmpId,EmpEduInfo,EmpFamilyInfo,EmpHobbies)
VALUES (2,'M.Tech','married','surfing')

INSERT INTO EmpOptionalData (EmpId,EmpEduInfo,EmpFamilyInfo,EmpHobbies)
VALUES (3,'MBA','single','trecking')

INSERT INTO EmpOptionalData (EmpId,EmpEduInfo,EmpFamilyInfo,EmpHobbies)
VALUES (4,'M.Sc.','na','driving')

﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DependencyCollector;
using Microsoft.ApplicationInsights.Extensibility;
using System.Net.Http;
using System.Threading.Tasks;

namespace ConsoleAppInsight
{
    class Program
    {
        static void Main(string[] args)
        {
            TelemetryConfiguration configuration = TelemetryConfiguration.Active;
            configuration.InstrumentationKey = "";
            configuration.TelemetryInitializers.Add(new OperationCorrelationTelemetryInitializer());
            configuration.TelemetryInitializers.Add(new HttpDependenciesParsingTelemetryInitializer());
            var telemetryClient = new TelemetryClient();
            using (InitializeDependencyTracking(configuration))
            {
               
                 telemetryClient.TrackTrace("Hello World!");
                using (var httpClient = new HttpClient())
                {
                    httpClient.GetAsync("https://microsoft.com").Wait();
                } 
             }
                
                telemetryClient.Flush();
               Task.Delay(5000).Wait(); 
        }
        static DependencyTrackingTelemetryModule InitializeDependencyTracking(TelemetryConfiguration configuration)
        {
            var module = new DependencyTrackingTelemetryModule();
            // prevent Correlation Id to be sent to certain endpoints. You may add other domains as needed.           
            module.ExcludeComponentCorrelationHttpHeadersOnDomains.Add("core.windows.net");
            module.ExcludeComponentCorrelationHttpHeadersOnDomains.Add("core.chinacloudapi.cn");
            module.ExcludeComponentCorrelationHttpHeadersOnDomains.Add("core.cloudapi.de");
            module.ExcludeComponentCorrelationHttpHeadersOnDomains.Add("core.usgovcloudapi.net");
            module.ExcludeComponentCorrelationHttpHeadersOnDomains.Add("localhost");
            module.ExcludeComponentCorrelationHttpHeadersOnDomains. Add("127.0.0.1");
                   
            module.IncludeDiagnosticSourceActivities.Add("Microsoft.Azure. ServiceBus");
            module.IncludeDiagnosticSourceActivities.Add("Microsoft.Azure. EventHubs"); 
            // initialize the module 
      
            module.Initialize(configuration);
            return module;
        }
    }
}

﻿using Microsoft.ApplicationInsights;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppInsight
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private TelemetryClient tc = new TelemetryClient();
        private void Form1_Load(object sender, EventArgs e)
        {
            // Alternative to setting ikey in config file:       
            tc.InstrumentationKey = "";
            // Set session data:         
            tc.Context.User.Id = Environment.UserName;
            tc.Context.Session.Id = Guid.NewGuid().ToString(); 
           tc.Context.Device.OperatingSystem = Environment.OSVersion.ToString();
            // Log a page view:        
            tc.TrackPageView("Form1"); 
        }
        protected override void OnClosing(CancelEventArgs e)
        {
           // stop = true;
            if (tc != null)
            {
                tc.Flush();             
                System.Threading.Thread.Sleep(1000);
            }
            base.OnClosing(e);
        } 

    }
}

﻿using Microsoft.TeamFoundation.WorkItemTracking.WebApi;
using Microsoft.VisualStudio.Services.Common;
using Microsoft.VisualStudio.Services.WebApi;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleCrWI
{
    class Program
    {
        static void Main(string[] args)
        {
            if (File.Exists("credentials.txt"))
            {
                StreamReader sr = new StreamReader("credentials.txt");
                string account = sr.ReadLine();
                string PAT = sr.ReadLine();
                //string projectName = "";
                VssConnection connection = null;
                connection = new VssConnection(new Uri("https://" + account + ".visualstudio.com"), new VssBasicCredential(string.Empty, PAT));
                
                var workitemClient = connection.GetClient<WorkItemTrackingHttpClient>();
                var document = new Microsoft.VisualStudio.Services.WebApi.Patch.Json.JsonPatchDocument();
                document.Add(
                new Microsoft.VisualStudio.Services.WebApi.Patch.Json.JsonPatchOperation()
                {
                    Path = "/fields/System.Title",
                    Operation = Microsoft.VisualStudio.Services.WebApi.Patch.Operation.Add,
                    Value = "From Program"
                });
                var worktime = workitemClient.CreateWorkItemAsync(document,"SLB Demo","Task").Result;
            }
            
        }
    }
}
